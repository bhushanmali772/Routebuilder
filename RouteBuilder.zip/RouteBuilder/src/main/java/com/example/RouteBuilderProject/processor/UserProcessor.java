package com.example.RouteBuilderProject.processor;

import com.example.RouteBuilderProject.entity.User;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class UserProcessor implements Processor {


    @Override
    public void process(Exchange exchange) throws Exception {
        User user = new User();
        user.setName(exchange.getIn().getBody(String.class));
        exchange.getIn().setBody(user);
    }
}
