package com.example.RouteBuilderProject;
import com.example.RouteBuilderProject.routebuilder.ProjectRouteBuilder;
import com.mongodb.client.MongoClient;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.camel.CamelContext;
import org.apache.camel.component.jms.JmsComponent;
import org.apache.camel.impl.DefaultCamelContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import javax.jms.ConnectionFactory;

@SpringBootApplication
public class RouteBuilderProjectApplication  implements CommandLineRunner {

	@Autowired
	private ApplicationContext appContext;

	@Autowired
	private MongoClient mongoClient;

	public static void main(String[] args) throws Exception {
		SpringApplication.run(RouteBuilderProjectApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		CamelContext camelContext = new DefaultCamelContext();
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory("tcp://localhost:61616");
		camelContext.addComponent("jms", JmsComponent.jmsComponentAutoAcknowledge(connectionFactory));
		camelContext.getRegistry().bind("mongoClient", mongoClient);
		camelContext.addRoutes(appContext.getBean(ProjectRouteBuilder.class));
		camelContext.start();
	}

}
