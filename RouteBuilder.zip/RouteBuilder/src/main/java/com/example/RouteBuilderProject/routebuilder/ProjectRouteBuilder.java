package com.example.RouteBuilderProject.routebuilder;
import com.example.RouteBuilderProject.processor.UserProcessor;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class ProjectRouteBuilder extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        from("jms:user-queue")
                .log("Message Received")
                .log("Received message from user-queue: ${body}")
                .onException(Exception.class)
                .log("Error occurred: ${exception.message}")
                .end()
                .process(new UserProcessor())
                .to("mongodb:mongoClient?database=employee&collection=user&operation=insert")
                .log("User Inserted");
    }
}

